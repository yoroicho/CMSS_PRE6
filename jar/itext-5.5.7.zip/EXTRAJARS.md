The extra jars (itext-asian, itext-hyph-xml, bc*,...) are NOT A PART of the iText project.
These jars are bundled for your convenience.
Please consult the separate license that is shipped with each jar for more info before using them.

Regarding BouncyCastle: please consult the POM file of the iText project to find out which version of the jars you need.